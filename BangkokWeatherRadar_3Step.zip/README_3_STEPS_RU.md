1) Upload this project to your personal GitHub repository.
2) Open Actions -> Build APK -> Run workflow.
3) Open the finished run -> Artifacts -> BangkokWeatherRadar-APK -> download ZIP and extract app-debug.apk.
