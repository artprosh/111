# Сборка APK через Appcircle

Этот проект подготовлен для облачной сборки без компьютера.

1. Загрузите содержимое этого проекта в GitHub-репозиторий.
2. В Appcircle создайте Build Profile → Android → Java/Kotlin.
3. Подключите GitHub-репозиторий.
4. В Configuration выберите:
   - Project path: пусто
   - Module: app
   - Variant: debug
   - Output type: APK
5. В Workflow должен использоваться Android Build.
6. Нажмите Start Build.
7. После успешной сборки скачайте APK из Artifacts.

В проект добавлен gradlew-лаунчер. Если на чистом cloud runner нет Gradle, он автоматически скачивает Gradle 9.6.0 и запускает сборку.
