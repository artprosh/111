@echo off
setlocal
set GRADLE_VERSION=9.6.0
set CACHE_DIR=%USERPROFILE%\.gradle\bangkok-weather-radar\gradle-%GRADLE_VERSION%
set GRADLE_HOME=%CACHE_DIR%\gradle-%GRADLE_VERSION%
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  if not exist "%CACHE_DIR%" mkdir "%CACHE_DIR%"
  set TMP_ZIP=%CACHE_DIR%\gradle-%GRADLE_VERSION%-bin.zip
  if not exist "%TMP_ZIP%" powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%TMP_ZIP%'"
  powershell -NoProfile -Command "Expand-Archive -Force '%TMP_ZIP%' '%CACHE_DIR%'"
)
call "%GRADLE_HOME%\bin\gradle.bat" %*
