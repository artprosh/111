#!/usr/bin/env bash
set -e
GRADLE_VERSION=9.6
curl -fsSL -o /tmp/gradle.zip https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip
rm -rf /tmp/gradle
mkdir /tmp/gradle
unzip -q /tmp/gradle.zip -d /tmp/gradle
/tmp/gradle/gradle-${GRADLE_VERSION}/bin/gradle assembleDebug --no-daemon --stacktrace
